package com.atguigu.gulimall.gateway;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
